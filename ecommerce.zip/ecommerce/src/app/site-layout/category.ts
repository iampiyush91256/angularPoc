export interface Category {
  id:string;
  productName:string;

}

