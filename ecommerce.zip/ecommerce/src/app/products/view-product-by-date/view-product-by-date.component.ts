import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-product-by-date',
  templateUrl: './view-product-by-date.component.html',
  styleUrls: ['./view-product-by-date.component.css']
})
export class ViewProductByDateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
